package com.example.quiz;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@RestController
@RequestMapping("/api")
public class QuizController {
    private final List<QuizQuestion> questions = List.of(
        new QuizQuestion(1, "Which annotation marks a Spring Boot application entry point?", List.of("@SpringBootApplication", "@RestController", "@Autowired", "@Bean"), 0, "@SpringBootApplication"),
        new QuizQuestion(2, "Which command builds a Docker image from a Dockerfile?", List.of("docker run", "docker build", "docker ps", "docker stop"), 1, "docker build"),
        new QuizQuestion(3, "Which HTTP method is commonly used to retrieve data from an API?", List.of("POST", "DELETE", "GET", "PATCH"), 2, "GET")
    );

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP", "application", "quiz-app");
    }

    @GetMapping("/quiz")
    public List<Map<String, Object>> getAllQuestions() {
        return questions.stream().map(this::publicQuestion).toList();
    }

    @GetMapping("/quiz/{id}")
    public Map<String, Object> getQuestion(@PathVariable int id) {
        return publicQuestion(findQuestion(id));
    }

    @PostMapping("/quiz/{id}/answer")
    public Map<String, Object> submitAnswer(@PathVariable int id, @RequestBody AnswerRequest request) {
        QuizQuestion question = findQuestion(id);
        if (request == null || request.optionIndex() == null || request.optionIndex() < 0 || request.optionIndex() >= question.options().size()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "optionIndex must be between 0 and " + (question.options().size() - 1));
        }
        boolean correct = request.optionIndex() == question.correctOptionIndex();
        return Map.of("questionId", id, "correct", correct, "selectedOption", question.options().get(request.optionIndex()), "correctAnswer", question.correctAnswer(), "message", correct ? "Correct answer!" : "Try again.");
    }

    private QuizQuestion findQuestion(int id) {
        return questions.stream().filter(q -> q.id() == id).findFirst()
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Question not found: " + id));
    }

    private Map<String, Object> publicQuestion(QuizQuestion q) {
        return Map.of("id", q.id(), "question", q.question(), "options", q.options());
    }

    public record QuizQuestion(int id, String question, List<String> options, int correctOptionIndex, String correctAnswer) {}
    public record AnswerRequest(Integer optionIndex) {}
}
